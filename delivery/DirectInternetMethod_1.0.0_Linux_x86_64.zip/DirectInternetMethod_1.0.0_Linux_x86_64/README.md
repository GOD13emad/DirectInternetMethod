# Direct Internet Method

Standalone Windows + Linux direct-connect product. It is independent of FreeNetHub and ChatGPT during normal use.

Linux architecture: temporary dedicated DNS link + ctrld 1.5.7/DoH + systemd-resolved routing + nftables/NFQUEUE + zapret nfqws 72.13. It does not create a VPN, HTTP/SOCKS proxy, or default-route tunnel.

Linux install: extract the release ZIP and run `bash install.sh`. The installer creates an Applications-menu launcher and icon. Start/Stop/Recovery use the normal polkit authentication prompt.

Windows architecture remains the accepted Loopback ULA + ctrld 1.5.7/DoH + NRPT + zapret/winws/WinDivert model.
